  <div class="container_16 containter_footer">
    <footer id="colophon" class="grid_16 site-footer" role="contentinfo">
      <?php do_action( 'contango_footer' ); ?>
    </footer>
  </div>

</div> <!-- end .wrapper -->

<?php wp_footer(); ?>
</body>
</html>